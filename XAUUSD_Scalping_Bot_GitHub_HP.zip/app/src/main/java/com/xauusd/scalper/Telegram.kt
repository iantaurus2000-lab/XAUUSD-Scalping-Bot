package com.xauusd.scalper
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Telegram {
    fun send(token:String, chatId:String, text:String):Boolean {
        if(token.isBlank() || chatId.isBlank()) return false
        return try {
            val c=URL("https://api.telegram.org/bot$token/sendMessage").openConnection() as HttpURLConnection
            c.requestMethod="POST"; c.doOutput=true; c.connectTimeout=10000; c.readTimeout=10000
            val body="chat_id="+URLEncoder.encode(chatId,"UTF-8")+"&text="+URLEncoder.encode(text,"UTF-8")
            c.outputStream.use{it.write(body.toByteArray())}
            c.responseCode in 200..299
        } catch(_:Exception){false}
    }
}
