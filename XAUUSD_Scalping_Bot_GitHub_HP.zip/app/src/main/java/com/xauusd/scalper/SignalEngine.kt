package com.xauusd.scalper

data class Signal(val side:String,val entry:Double,val sl:Double,val tp:Double,val score:Int,val reason:String)

object SignalEngine {
    fun evaluate(m5:List<Candle>, m1:List<Candle>):Signal? {
        if(m5.size<60 || m1.size<30) return null
        val e20=ema(m5.map{it.c},20).last(); val e50=ema(m5.map{it.c},50).last()
        val bullish=e20>e50
        val b=m1.last()
        val prev=m1.subList(m1.size-8,m1.size-1)
        val lo=prev.minOf{it.l}; val hi=prev.maxOf{it.h}
        val body=kotlin.math.abs(b.c-b.o)
        val lw=minOf(b.o,b.c)-b.l; val uw=b.h-maxOf(b.o,b.c)
        val a=atr(m1,14)
        val sweepLow=b.l<lo && b.c>lo && lw>body*1.2
        val sweepHigh=b.h>hi && b.c<hi && uw>body*1.2
        val bosUp=b.c>hi; val bosDn=b.c<lo
        val buy=bullish && sweepLow && bosUp
        val sell=!bullish && sweepHigh && bosDn
        if(!buy && !sell) return null
        val score=100
        return if(buy){
            val sl=b.l-a*0.25; val tp=b.c+(b.c-sl)*1.8
            Signal("BUY",b.c,sl,tp,score,"M5 bullish bias + M1 liquidity sweep + wick rejection + BOS")
        } else {
            val sl=b.h+a*0.25; val tp=b.c-(sl-b.c)*1.8
            Signal("SELL",b.c,sl,tp,score,"M5 bearish bias + M1 liquidity sweep + wick rejection + BOS")
        }
    }
    private fun ema(x:List<Double>,p:Int):List<Double>{
        val k=2.0/(p+1); val r=MutableList(x.size){0.0}; r[0]=x[0]
        for(i in 1 until x.size) r[i]=x[i]*k+r[i-1]*(1-k)
        return r
    }
    private fun atr(x:List<Candle>,p:Int):Double{
        val trs=x.zipWithNext().map{(a,b)->maxOf(b.h-b.l,kotlin.math.abs(b.h-a.c),kotlin.math.abs(b.l-a.c))}
        return trs.takeLast(p).average()
    }
}
