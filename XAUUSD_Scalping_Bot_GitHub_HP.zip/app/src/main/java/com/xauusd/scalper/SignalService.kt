package com.xauusd.scalper

import android.app.*
import android.content.Intent
import android.os.IBinder
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class SignalService: Service(){
    companion object{const val START="START"; const val STOP="STOP"}
    private val exec=Executors.newSingleThreadScheduledExecutor()
    private var running=false
    private var token=""; private var chat=""; private var api=""; private var lastKey=""

    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{
        if(i?.action==STOP){running=false;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return START_NOT_STICKY}
        if(i?.action==START){
            api=i.getStringExtra("apiKey")?:""; token=i.getStringExtra("token")?:""; chat=i.getStringExtra("chatId")?:""
            startForeground(7,notification())
            if(!running){running=true;exec.scheduleWithFixedDelay({cycle()},0,60,TimeUnit.SECONDS)}
        }
        return START_STICKY
    }
    private fun notification():Notification{
        val ch="xau_signal"
        val nm=getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch,"XAUUSD Signal Bot",NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this,ch).setContentTitle("XAUUSD Scalping Bot")
            .setContentText("Monitoring M1/M5").setSmallIcon(android.R.drawable.ic_dialog_info).build()
    }
    private fun cycle(){
        try{
            val m5=Market.candles(api,"5min",120); val m1=Market.candles(api,"1min",120)
            val s=SignalEngine.evaluate(m5,m1) ?: return
            val key=s.side+"_"+s.entry
            if(key==lastKey)return
            lastKey=key
            val msg="🚨 XAUUSD SIGNAL\n\n${s.side}\nEntry: %.2f\nSL: %.2f\nTP: %.2f\nScore: %d/100\n\n%s\n\n⚠️ Sinyal otomatis, bukan jaminan profit."
                .format(s.entry,s.sl,s.tp,s.score,s.reason)
            Telegram.send(token,chat,msg)
        }catch(_:Exception){}
    }
    override fun onBind(i:Intent?):IBinder?=null
}
