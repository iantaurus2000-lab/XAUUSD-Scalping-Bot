package com.xauusd.scalper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private lateinit var api: EditText
    private lateinit var token: EditText
    private lateinit var chat: EditText
    private lateinit var status: TextView
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        api=findViewById(R.id.apiKey); token=findViewById(R.id.botToken); chat=findViewById(R.id.chatId)
        status=findViewById(R.id.status); log=findViewById(R.id.log)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)

        findViewById<Button>(R.id.startBtn).setOnClickListener {
            val i=Intent(this, SignalService::class.java).apply {
                action=SignalService.START
                putExtra("apiKey",api.text.toString().trim())
                putExtra("token",token.text.toString().trim())
                putExtra("chatId",chat.text.toString().trim())
            }
            if (Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
            status.text="Status: RUNNING"; log.text="Monitoring XAU/USD otomatis."
        }
        findViewById<Button>(R.id.stopBtn).setOnClickListener {
            startService(Intent(this,SignalService::class.java).apply{action=SignalService.STOP})
            status.text="Status: STOPPED"; log.text="Bot dihentikan."
        }
        findViewById<Button>(R.id.testBtn).setOnClickListener {
            Thread {
                val ok=Telegram.send(token.text.toString().trim(),chat.text.toString().trim(),
                    "✅ XAUUSD Scalping Bot: TEST TELEGRAM berhasil.")
                runOnUiThread { log.text=if(ok) "Telegram OK." else "Telegram gagal. Periksa token & chat ID." }
            }.start()
        }
    }
}
