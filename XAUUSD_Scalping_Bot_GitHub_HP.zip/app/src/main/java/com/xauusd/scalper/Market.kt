package com.xauusd.scalper
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Candle(val t:String,val o:Double,val h:Double,val l:Double,val c:Double,val v:Double)

object Market {
    fun candles(api:String, interval:String, n:Int=100):List<Candle>{
        val url="https://api.twelvedata.com/time_series?symbol=XAU/USD&interval=$interval&outputsize=$n&apikey=$api"
        val con=URL(url).openConnection() as HttpURLConnection
        con.connectTimeout=12000; con.readTimeout=12000
        val root=JSONObject(con.inputStream.bufferedReader().readText())
        if(root.optString("status")=="error") throw Exception(root.optString("message"))
        val arr=root.getJSONArray("values")
        val out=mutableListOf<Candle>()
        for(i in arr.length()-1 downTo 0){
            val x=arr.getJSONObject(i)
            out.add(Candle(x.getString("datetime"),x.getDouble("open"),x.getDouble("high"),
                x.getDouble("low"),x.getDouble("close"),x.optDouble("volume",0.0)))
        }
        return out
    }
}
