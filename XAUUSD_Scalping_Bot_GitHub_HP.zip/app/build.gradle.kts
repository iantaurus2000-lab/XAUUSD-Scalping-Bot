plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.xauusd.scalper"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.xauusd.scalper"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
