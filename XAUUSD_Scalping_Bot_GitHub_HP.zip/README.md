# XAUUSD Scalping Bot — Build dari HP

Data XAU/USD diambil otomatis dari Twelve Data. Mesin sinyal memakai M5 sebagai bias dan M1 sebagai pemicu: liquidity sweep, wick rejection, dan BOS. Sinyal dikirim ke Telegram.

### Yang perlu disiapkan
- Twelve Data API key
- Telegram Bot Token
- Telegram Chat ID

### Build tanpa PC
Upload seluruh isi proyek ke GitHub. Setelah itu:
1. Buka tab **Actions**
2. Pilih **Build APK**
3. Tekan **Run workflow**
4. Tunggu sampai selesai
5. Buka hasil workflow → **Artifacts**
6. Download `XAUUSD-Scalping-Bot-APK.zip` dan ekstrak APK.

GitHub Actions menjalankan Gradle di server, sehingga AndroidIDE dan Termux tidak diperlukan. GitHub mendokumentasikan Actions sebagai sistem otomatisasi build/test/deploy, termasuk proyek Gradle. 

Catatan: aplikasi ini hanya mengirim sinyal dan tidak membuka posisi broker. API key dan token Telegram dimasukkan di aplikasi, bukan di repository. Untuk pemakaian lama, Android dapat membatasi aktivitas background/ baterai.
