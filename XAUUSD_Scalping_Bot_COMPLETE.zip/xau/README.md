# XAUUSD Scalping Bot - Android

Complete Android Studio/Gradle project intended for building through GitHub Actions from a phone.

## Build
1. Upload the contents of this project to a GitHub repository.
2. Open Actions.
3. Run `Build XAUUSD APK`.
4. Download artifact `XAUUSD-Scalping-Bot-APK`.

## Important
This app sends signals only; it does not place broker trades. A Twelve Data API key and Telegram bot token/chat ID are required. The included signal engine is a conservative starter implementation and is not a guarantee of profit.
