package com.xauusd.scalper

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : android.app.Activity() {
    private lateinit var api: EditText; private lateinit var token: EditText; private lateinit var chat: EditText; private lateinit var status: TextView; private lateinit var log: TextView
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        api=findViewById(R.id.apiKey); token=findViewById(R.id.botToken); chat=findViewById(R.id.chatId); status=findViewById(R.id.status); log=findViewById(R.id.log)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5)
        findViewById<Button>(R.id.start).setOnClickListener { startBot() }
        findViewById<Button>(R.id.stop).setOnClickListener { stopService(Intent(this, SignalService::class.java)); status.text="Status: STOPPED" }
        findViewById<Button>(R.id.test).setOnClickListener { Thread { val ok=Telegram.send(token.text.toString().trim(), chat.text.toString().trim(), "TEST XAUUSD Scalping Bot: Telegram terhubung."); runOnUiThread { log.text=if(ok) "Telegram OK" else "Telegram gagal" } }.start() }
    }
    private fun startBot() { val i=Intent(this, SignalService::class.java).apply { putExtra("api",api.text.toString().trim()); putExtra("token",token.text.toString().trim()); putExtra("chat",chat.text.toString().trim()) }; if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i); status.text="Status: RUNNING"; log.text="Bot berjalan. Pemeriksaan setiap 60 detik." }
}
