package com.xauusd.scalper

import kotlin.math.abs

object SignalEngine {
    fun build(m5: Double?, m1: Double?): String? {
        if (m5 == null || m1 == null) return null
        // Conservative placeholder signal engine: only emits when M1 and M5 prices align.
        // Replace with candle-history logic when a broker/data feed is connected.
        val diff = abs(m1 - m5)
        if (diff > 2.0) return null
        val side = if (m1 >= m5) "BUY" else "SELL"
        val sl = if (side == "BUY") m1 - 1.5 else m1 + 1.5
        val tp = if (side == "BUY") m1 + 2.7 else m1 - 2.7
        return "XAUUSD $side\nEntry: %.2f\nSL: %.2f\nTP: %.2f\nRR: 1:1.8\n\nSignal engine: M5/M1 alignment".format(m1, sl, tp)
    }
}
