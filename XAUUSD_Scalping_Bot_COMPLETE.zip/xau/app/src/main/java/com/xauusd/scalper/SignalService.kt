package com.xauusd.scalper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.*

class SignalService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var apiKey = ""; private var token = ""; private var chat = ""
    private var last = ""

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        apiKey = intent?.getStringExtra("api") ?: apiKey
        token = intent?.getStringExtra("token") ?: token
        chat = intent?.getStringExtra("chat") ?: chat
        createChannel(); startForeground(7, notification("Bot aktif"))
        scope.coroutineContext.cancelChildren()
        scope.launch {
            while (isActive) {
                val m5 = Market.latest(apiKey, "5min")
                val m1 = Market.latest(apiKey, "1min")
                val signal = SignalEngine.build(m5, m1)
                if (!signal.isNullOrBlank() && signal != last) { Telegram.send(token, chat, signal); last = signal }
                delay(60000)
            }
        }
        return START_STICKY
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("xau", "XAUUSD Bot", NotificationManager.IMPORTANCE_LOW))
    }
    private fun notification(text: String): Notification = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "xau").setContentTitle("XAUUSD Scalping Bot").setContentText(text).setSmallIcon(android.R.drawable.ic_dialog_info).build() else Notification.Builder(this).setContentTitle("XAUUSD Scalping Bot").setContentText(text).setSmallIcon(android.R.drawable.ic_dialog_info).build()
}
