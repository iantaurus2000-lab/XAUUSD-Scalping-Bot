package com.xauusd.scalper

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Market {
    fun latest(apiKey: String, interval: String): Double? {
        return try {
            val u = "https://api.twelvedata.com/time_series?symbol=XAU/USD&interval=$interval&outputsize=10&apikey=$apiKey"
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 10000; c.readTimeout = 10000
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val values = JSONObject(text).optJSONArray("values") ?: return null
            values.getJSONObject(0).optString("close").toDoubleOrNull()
        } catch (_: Exception) { null }
    }
}
